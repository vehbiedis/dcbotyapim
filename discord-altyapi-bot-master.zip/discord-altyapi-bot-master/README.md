Bot Altyapı Projesine Hoşgeldin!
=================
 Bu Dosya Tamamen `Emirhan Saraç'a Aittir`. Bot Altyapısını Sizlerin Kullanması İçin Verdik Gerekli Modüller Yüklüdür..!

[Resmi Discord Sunucumuz](https://discord.gg/cv45tPg)

[Resmi Youtube Kanalımız](https://www.youtube.com/channel/UCVRhrcoG6FOvHGKehYtvKHg?view_as=subscriber)

[Resmi İnstagram Hesabımız](https://www.instagram.com/emirhansarac06/)

Discord.js v12 Bu Altyapıda Çalışmaz. Discord.js'yi Güncellemeyin!

-------------------

`İyi Kullanımlar!`

